
import { combineReducers } from 'redux';
import blog from './blog'
import jokes from './jokes'
export default combineReducers({
    blog,
    jokes
});
