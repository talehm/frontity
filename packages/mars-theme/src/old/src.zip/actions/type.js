export const ALL_JOKES = 'ALL_JOKES'
export const SINGLE_JOKE = 'SINGLE_JOKE'
export const ALL_BLOGS = 'ALL_BLOGS'
export const SINGLE_ARTICLE = 'SINGLE_ARTICLE'